package appeng.api.me.util;

import java.util.List;

import net.minecraft.item.ItemStack;

public class InterfaceCraftingResponse {
	
	public ItemStack Request;
	
	public List<ItemStack> UsedMaterials;
	
}
