package appeng.api.me.tiles;

import java.util.List;

import net.minecraft.item.ItemStack;

public class InterfaceCraftingPattern {
	
	public List<ItemStack> Inputs;
	public ItemStack Output;
	
}
